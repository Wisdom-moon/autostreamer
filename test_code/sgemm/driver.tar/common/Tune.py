#!/usr/bin/env python

import os
import sys
import time
import subprocess
import signal

if len(sys.argv) < 2:
    print 'usage err!'
    quit()
argc = 2
cmd = (sys.argv[1],)
while (argc < len(sys.argv)):
    cmd += (sys.argv[argc],)
    argc += 1

cmd_tmp = cmd + ('1', '1')
t0 = time.time()
p = subprocess.Popen(cmd_tmp, stdout = None, stderr = None)
p.wait()
limit = 2 * (time.time() - t0)

f = open('log_'+os.getenv("LOG_NAME"), 'w')
for iter in range(1,4,1):
    for partitions in range(1, 57, 1):
        for blocks in [x * partitions for x in range(1, 21, 1) if x * partitions < 225]:
            cmd_tmp = cmd + (str(partitions), str(blocks))
            t0 = time.time()
            p = subprocess.Popen(cmd_tmp, stdout = f, stderr = f)

            while p.returncode is None:
                if time.time() > t0 + limit:
                    p.terminate()
                    p.wait()
                else:
                    # still waiting...
                    time.sleep(limit / 4)
                    p.poll()

f.close()
