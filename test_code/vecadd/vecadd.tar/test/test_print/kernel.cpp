#include <omp.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <sink/COIPipeline_sink.h>


COINATIVELIBEXPORT
void kernel( uint64_t arg0, uint64_t arg1)
{
  int n = (int) arg0;
  int *c = (int *)arg1;

 if ( n > 1 && (c[n] - c[n-1]) != 1)
    printf("Error at %d, this = %d, pre = %d\n",n, c[n], c[n-1]);

}

