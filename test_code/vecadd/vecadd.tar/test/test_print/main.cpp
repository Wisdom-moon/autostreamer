#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <omp.h>
#include <sys/time.h>

#include <hStreams_source.h>
#include <hStreams_app_api.h>
#include <common/COIMacros_common.h>

static HSTR_OPTIONS hstreams_options;

int main( int argc, char **argv)
{
  uint32_t places_per_domain = 7;
  uint32_t streams_per_place = 1;
  int stream = 0;
  int MAXLOGSTR = places_per_domain;
  int tasks = 1;
  int i;

  int length = atoi(argv[1]);
  int * str = (int *) malloc (length * sizeof (int));

  for (int i = 0; i < length; i++)
    str[i] = i;


  hStreams_GetCurrentOptions(&hstreams_options, sizeof(hstreams_options));
  hstreams_options.verbose = 0;
  hstreams_options.phys_domains_limit = 256;
  char *libNames[20] = {NULL, NULL};
  unsigned int libNameCnt = 0;
  libNames[libNameCnt++] = "kernel.so";
  hstreams_options.libNames = libNames;
  hstreams_options.libNameCnt = (uint16_t) libNameCnt;
  hStreams_SetOptions (&hstreams_options);

  int iret = hStreams_app_init (places_per_domain, streams_per_place);
  if (iret != 0)
  {
    printf ("hstreams_app_init failed!\n");
    exit (-1);
  }

  CHECK_HSTR_RESULT (hStreams_app_create_buf (str, sizeof(int) * length));
  HSTR_EVENT *pEvents = (HSTR_EVENT *) malloc (length * sizeof (HSTR_EVENT));
  hStreams_ThreadSynchronize ();

  struct timeval t_start, t_end;
  gettimeofday (&t_start, NULL);

  uint64_t arg[2];
  arg[1] = (uint64_t) str;

    arg[0] = (uint64_t) 0;
    CHECK_HSTR_RESULT (hStreams_app_xfer_memory (&str[0], &str[0], sizeof(int), 0 % MAXLOGSTR, HSTR_SRC_TO_SINK, &pEvents[0]));
    CHECK_HSTR_RESULT (hStreams_EnqueueCompute (0 % MAXLOGSTR, "kernel", 1, 1, arg, NULL, NULL, 0));

  for (int i = 1; i < length; i++)
  {    
    arg[0] = (uint64_t) i;
    hStreams_EventStreamWait(i % MAXLOGSTR, 1, &pEvents[i-1], 0, NULL, NULL);
    CHECK_HSTR_RESULT (hStreams_app_xfer_memory (&str[i], &str[i], sizeof(int), i % MAXLOGSTR, HSTR_SRC_TO_SINK, &pEvents[i]));
    CHECK_HSTR_RESULT (hStreams_EnqueueCompute (i % MAXLOGSTR, "kernel", 1, 1, arg, NULL, NULL, 0));
  }

  hStreams_ThreadSynchronize ();
  gettimeofday (&t_end, NULL);
  printf("Kernel + transfer: %ld us\n",1000000 * (t_end.tv_sec - t_start.tv_sec)
					+ t_end.tv_usec - t_start.tv_usec );

  hStreams_app_fini ();

  return 0;
}

